import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Library, Search, Sparkles, Cpu } from "lucide-react";

const items = [
  { to: "/", label: "Home", icon: Home },
  { to: "/search", label: "Search", icon: Search },
  { to: "/library", label: "Library", icon: Library },
  { to: "/recommendations", label: "For You", icon: Sparkles },
  { to: "/dsa", label: "DSA", icon: Cpu },
];

export function MobileNav() {
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  return (
    <nav className="glass-strong sticky top-0 z-20 flex items-center justify-around gap-1 border-b border-white/5 px-2 py-2 md:hidden">
      {items.map(({ to, label, icon: Icon }) => {
        const active = pathname === to;
        return (
          <Link
            key={to}
            to={to}
            className={`flex flex-1 flex-col items-center gap-0.5 rounded-md px-2 py-1 text-[10px] ${
              active ? "text-brand" : "text-muted-foreground"
            }`}
          >
            <Icon className="h-4 w-4" />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}