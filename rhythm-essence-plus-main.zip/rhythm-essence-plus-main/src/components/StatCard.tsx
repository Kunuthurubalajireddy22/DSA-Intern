import type { ReactNode } from "react";

export function StatCard({ label, value, icon }: { label: string; value: ReactNode; icon?: ReactNode }) {
  return (
    <div className="glass flex items-center gap-4 rounded-xl p-4">
      {icon && <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-brand text-brand-foreground">{icon}</div>}
      <div>
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="text-xl font-bold">{value}</div>
      </div>
    </div>
  );
}