import { Heart, MoreHorizontal, Play, Plus, Star, Trash2 } from "lucide-react";
import { AlbumCover } from "./AlbumCover";
import { fmtDuration, useMusic } from "@/lib/music-store";
import type { Song } from "@/lib/types";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator,
  DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Props {
  index: number;
  song: Song;
  playlistId?: string;
  contextIds?: string[];
}

export function SongRow({ index, song, playlistId, contextIds }: Props) {
  const {
    loadAndPlay, toggleFavorite, deleteSong, removeSongFromPlaylist,
    enqueueNext, state, addSongToPlaylist, player,
  } = useMusic();
  const isPlaying = player.currentId === song.id;

  return (
    <div className={`group grid grid-cols-[2rem_1fr_auto] items-center gap-3 rounded-lg px-3 py-2 transition-colors hover:bg-white/5 md:grid-cols-[2rem_minmax(0,3fr)_minmax(0,2fr)_minmax(0,1.5fr)_5rem_5rem] ${isPlaying ? "bg-white/5" : ""}`}>
      <div className="grid place-items-center text-sm text-muted-foreground">
        <span className="group-hover:hidden">{isPlaying ? <span className="text-brand">♪</span> : index + 1}</span>
        <button
          onClick={() => loadAndPlay(contextIds ?? [song.id], song.id)}
          className="hidden text-foreground group-hover:block"
          aria-label="Play"
        >
          <Play className="h-4 w-4 fill-current" />
        </button>
      </div>
      <div className="flex min-w-0 items-center gap-3">
        <AlbumCover hue={song.coverHue} size={40} />
        <div className="min-w-0">
          <div className={`truncate text-sm font-medium ${isPlaying ? "text-brand" : ""}`}>{song.name}</div>
          <div className="truncate text-xs text-muted-foreground">{song.artist}</div>
        </div>
      </div>
      <div className="hidden truncate text-sm text-muted-foreground md:block">{song.album}</div>
      <div className="hidden md:block">
        <span className="rounded-full bg-white/5 px-2 py-0.5 text-xs text-muted-foreground">{song.genre}</span>
      </div>
      <div className="hidden items-center gap-1 text-xs text-muted-foreground md:flex">
        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
        {song.rating.toFixed(1)}
      </div>
      <div className="flex items-center justify-end gap-2">
        <button
          onClick={() => toggleFavorite(song.id)}
          className={`rounded-full p-1.5 transition-all hover:scale-110 hover:text-pink-400 ${song.favorite ? "text-pink-400" : "text-muted-foreground opacity-0 group-hover:opacity-100"}`}
          aria-label="Favorite"
        >
          <Heart className={`h-4 w-4 ${song.favorite ? "fill-pink-400" : ""}`} />
        </button>
        <span className="hidden font-mono text-xs text-muted-foreground md:inline">{fmtDuration(song.duration)}</span>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground" aria-label="More">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="glass-strong border-white/10">
            <DropdownMenuItem onClick={() => enqueueNext(song.id)}>
              <Plus className="mr-2 h-4 w-4" /> Add to Play Next
            </DropdownMenuItem>
            <DropdownMenuSub>
              <DropdownMenuSubTrigger>Add to playlist</DropdownMenuSubTrigger>
              <DropdownMenuSubContent className="glass-strong border-white/10">
                {state.playlists.length === 0 && <DropdownMenuItem disabled>No playlists yet</DropdownMenuItem>}
                {state.playlists.map((p) => (
                  <DropdownMenuItem key={p.id} onClick={() => addSongToPlaylist(p.id, song.id)}>
                    {p.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuSubContent>
            </DropdownMenuSub>
            <DropdownMenuSeparator />
            {playlistId ? (
              <DropdownMenuItem onClick={() => removeSongFromPlaylist(playlistId, song.id)}>
                <Trash2 className="mr-2 h-4 w-4" /> Remove from this playlist
              </DropdownMenuItem>
            ) : (
              <DropdownMenuItem onClick={() => deleteSong(song.id)}>
                <Trash2 className="mr-2 h-4 w-4" /> Delete from library
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

export function SongTableHeader() {
  return (
    <div className="hidden px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground md:grid md:grid-cols-[2rem_minmax(0,3fr)_minmax(0,2fr)_minmax(0,1.5fr)_5rem_5rem] md:gap-3">
      <div className="text-center">#</div>
      <div>Title</div>
      <div>Album</div>
      <div>Genre</div>
      <div>Rating</div>
      <div className="text-right">Actions</div>
    </div>
  );
}