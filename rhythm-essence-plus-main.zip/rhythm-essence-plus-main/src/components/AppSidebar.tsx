import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Library, ListMusic, Search, Sparkles, Cpu, Heart, Plus } from "lucide-react";
import { useMusic } from "@/lib/music-store";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

const nav = [
  { to: "/", label: "Home", icon: Home },
  { to: "/search", label: "Search", icon: Search },
  { to: "/library", label: "Library", icon: Library },
  { to: "/recommendations", label: "For You", icon: Sparkles },
  { to: "/dsa", label: "DSA Explorer", icon: Cpu },
];

export function AppSidebar() {
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const { state, createPlaylist } = useMusic();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");

  return (
    <aside className="glass sticky top-0 hidden h-screen w-64 shrink-0 flex-col gap-4 border-r border-white/5 p-4 md:flex">
      <Link to="/" className="flex items-center gap-2 px-2 pt-2">
        <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-brand shadow-glow">
          <ListMusic className="h-5 w-5 text-brand-foreground" />
        </div>
        <div className="font-display text-lg font-bold tracking-tight">Sonata<span className="text-gradient-brand">.</span></div>
      </Link>

      <nav className="flex flex-col gap-1">
        {nav.map(({ to, label, icon: Icon }) => {
          const active = pathname === to || (to !== "/" && pathname.startsWith(to));
          return (
            <Link
              key={to}
              to={to}
              className={`group flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all ${
                active ? "bg-white/10 text-foreground" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
            >
              <Icon className={`h-4 w-4 transition-transform group-hover:scale-110 ${active ? "text-brand" : ""}`} />
              <span>{label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="my-2 h-px bg-white/5" />

      <div className="flex items-center justify-between px-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Playlists</span>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <button className="grid h-6 w-6 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground" aria-label="New playlist">
              <Plus className="h-4 w-4" />
            </button>
          </DialogTrigger>
          <DialogContent className="glass-strong border-white/10">
            <DialogHeader><DialogTitle>New playlist</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <Input placeholder="Playlist name" value={name} onChange={(e) => setName(e.target.value)} />
              <Textarea placeholder="Description (optional)" value={desc} onChange={(e) => setDesc(e.target.value)} />
            </div>
            <DialogFooter>
              <Button
                onClick={() => {
                  if (!name.trim()) return;
                  createPlaylist(name.trim(), desc.trim() || undefined);
                  setName(""); setDesc(""); setOpen(false);
                }}
                className="bg-gradient-brand text-brand-foreground hover:opacity-90"
              >
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="-mx-2 flex flex-1 flex-col gap-0.5 overflow-y-auto px-2">
        <Link
          to="/favorites"
          className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
            pathname === "/favorites" ? "bg-white/10" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
          }`}
        >
          <div className="grid h-7 w-7 place-items-center rounded-md bg-gradient-to-br from-pink-500 to-purple-500">
            <Heart className="h-3.5 w-3.5" />
          </div>
          <div className="flex-1 truncate">Favorites</div>
          <span className="text-xs text-muted-foreground">{state.favorites.length}</span>
        </Link>

        {state.playlists.map((p) => {
          const active = pathname === `/playlists/${p.id}`;
          const hue = (p.name.charCodeAt(0) * 7) % 360;
          return (
            <Link
              key={p.id}
              to="/playlists/$id"
              params={{ id: p.id }}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                active ? "bg-white/10" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
            >
              <div
                className="cover-art h-7 w-7 shrink-0 rounded-md"
                style={{ ["--cover-hue" as string]: hue }}
              />
              <div className="min-w-0 flex-1 truncate">{p.name}</div>
              <span className="text-xs text-muted-foreground">{p.songIds.length}</span>
            </Link>
          );
        })}
      </div>
    </aside>
  );
}