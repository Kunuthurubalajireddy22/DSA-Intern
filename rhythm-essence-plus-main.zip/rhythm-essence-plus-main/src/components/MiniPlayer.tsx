import {
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Repeat1, Volume2, Heart, ListMusic,
} from "lucide-react";
import { AlbumCover } from "./AlbumCover";
import { fmtDuration, useMusic } from "@/lib/music-store";
import { Slider } from "@/components/ui/slider";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

export function MiniPlayer() {
  const {
    player, songById, togglePlay, next, prev, setShuffle, cycleRepeat, setVolume, seek,
    toggleFavorite,
  } = useMusic();
  const song = player.currentId ? songById(player.currentId) : null;

  return (
    <div className="glass-strong sticky bottom-0 z-30 mx-3 mb-3 flex items-center gap-3 rounded-2xl border-white/10 p-3 shadow-glow md:mx-4 md:mb-4 md:gap-6 md:p-4">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        {song ? (
          <>
            <AlbumCover hue={song.coverHue} size={56} spinning={player.playing} />
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold">{song.name}</div>
              <div className="truncate text-xs text-muted-foreground">{song.artist}</div>
            </div>
            <button
              onClick={() => toggleFavorite(song.id)}
              className="hidden shrink-0 rounded-full p-2 text-muted-foreground transition-all hover:scale-110 hover:text-pink-400 md:block"
              aria-label="Favorite"
            >
              <Heart className={`h-4 w-4 ${song.favorite ? "fill-pink-400 text-pink-400" : ""}`} />
            </button>
          </>
        ) : (
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <div className="grid h-14 w-14 place-items-center rounded-lg bg-white/5">
              <ListMusic className="h-5 w-5" />
            </div>
            Pick a song to start
          </div>
        )}
      </div>

      <div className="flex flex-[2] flex-col items-center gap-2">
        <div className="flex items-center gap-1 md:gap-3">
          <button
            onClick={() => setShuffle(!player.shuffle)}
            className={`rounded-full p-2 transition-all hover:scale-110 ${player.shuffle ? "text-brand" : "text-muted-foreground"}`}
            aria-label="Shuffle"
          >
            <Shuffle className="h-4 w-4" />
          </button>
          <button onClick={prev} className="rounded-full p-2 text-foreground transition-all hover:scale-110" aria-label="Previous">
            <SkipBack className="h-5 w-5" />
          </button>
          <button
            onClick={togglePlay}
            disabled={!song}
            className="grid h-10 w-10 place-items-center rounded-full bg-gradient-brand text-brand-foreground shadow-glow transition-all hover:scale-105 disabled:opacity-50"
            aria-label={player.playing ? "Pause" : "Play"}
          >
            {player.playing ? <Pause className="h-4 w-4" /> : <Play className="ml-0.5 h-4 w-4" />}
          </button>
          <button onClick={next} className="rounded-full p-2 text-foreground transition-all hover:scale-110" aria-label="Next">
            <SkipForward className="h-5 w-5" />
          </button>
          <button
            onClick={cycleRepeat}
            className={`rounded-full p-2 transition-all hover:scale-110 ${player.repeat !== "off" ? "text-brand" : "text-muted-foreground"}`}
            aria-label="Repeat"
          >
            {player.repeat === "one" ? <Repeat1 className="h-4 w-4" /> : <Repeat className="h-4 w-4" />}
          </button>
        </div>
        <div className="hidden w-full items-center gap-2 md:flex">
          <span className="w-10 text-right font-mono text-[10px] text-muted-foreground">
            {song ? fmtDuration(song.duration * player.progress) : "0:00"}
          </span>
          <Slider
            value={[player.progress * 100]}
            max={100}
            step={0.5}
            onValueChange={(v) => seek((v[0] ?? 0) / 100)}
            className="flex-1"
          />
          <span className="w-10 font-mono text-[10px] text-muted-foreground">{song ? fmtDuration(song.duration) : "0:00"}</span>
        </div>
      </div>

      <div className="hidden flex-1 items-center justify-end gap-3 md:flex">
        <Popover>
          <PopoverTrigger asChild>
            <button className="rounded-full p-2 text-muted-foreground hover:text-foreground" aria-label="Queue">
              <ListMusic className="h-4 w-4" />
              {player.queue.length > 0 && (
                <span className="ml-1 rounded-full bg-brand/20 px-1.5 text-[10px] text-brand">{player.queue.length}</span>
              )}
            </button>
          </PopoverTrigger>
          <PopoverContent align="end" className="glass-strong w-72 border-white/10">
            <div className="mb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Play Next Queue</div>
            {player.queue.length === 0 ? (
              <div className="text-sm text-muted-foreground">Nothing queued.</div>
            ) : (
              <ul className="space-y-1">
                {player.queue.map((id, i) => {
                  const s = songById(id);
                  if (!s) return null;
                  return (
                    <li key={`${id}-${i}`} className="flex items-center gap-2 text-sm">
                      <span className="w-4 text-right text-xs text-muted-foreground">{i + 1}</span>
                      <AlbumCover hue={s.coverHue} size={28} />
                      <span className="truncate">{s.name}</span>
                    </li>
                  );
                })}
              </ul>
            )}
          </PopoverContent>
        </Popover>
        <Volume2 className="h-4 w-4 text-muted-foreground" />
        <Slider value={[player.volume * 100]} max={100} onValueChange={(v) => setVolume((v[0] ?? 0) / 100)} className="w-28" />
      </div>
    </div>
  );
}