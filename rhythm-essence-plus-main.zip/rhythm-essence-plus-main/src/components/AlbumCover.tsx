import { Music } from "lucide-react";

interface Props {
  hue: number;
  size?: number;
  className?: string;
  spinning?: boolean;
}

/** CSS-only album artwork so no external images are needed. */
export function AlbumCover({ hue, size = 48, className = "", spinning = false }: Props) {
  return (
    <div
      className={`cover-art relative flex shrink-0 items-center justify-center rounded-lg overflow-hidden ${spinning ? "animate-spin-slow rounded-full" : ""} ${className}`}
      style={{ ["--cover-hue" as string]: hue, width: size, height: size }}
    >
      <Music className="h-1/3 w-1/3 text-white/60" />
      <div className="pointer-events-none absolute inset-0 bg-black/10" />
    </div>
  );
}