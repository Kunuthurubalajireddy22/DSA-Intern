import type { ReactNode } from "react";

interface Props {
  title: string;
  subtitle?: string;
  eyebrow?: string;
  actions?: ReactNode;
  children: ReactNode;
  hue?: number;
}

export function PageShell({ title, subtitle, eyebrow, actions, children, hue = 152 }: Props) {
  return (
    <div className="animate-float-in">
      <div
        className="relative overflow-hidden rounded-2xl px-6 py-10 md:px-10 md:py-14"
        style={{
          background: `linear-gradient(135deg, oklch(0.35 0.16 ${hue}) 0%, oklch(0.20 0.05 ${hue + 20}) 100%)`,
        }}
      >
        <div className="pointer-events-none absolute inset-0 bg-black/20" />
        <div className="relative">
          {eyebrow && <div className="mb-2 text-xs font-semibold uppercase tracking-widest text-white/70">{eyebrow}</div>}
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="min-w-0">
              <h1 className="text-3xl font-bold md:text-5xl">{title}</h1>
              {subtitle && <p className="mt-2 max-w-2xl text-sm text-white/80 md:text-base">{subtitle}</p>}
            </div>
            {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
          </div>
        </div>
      </div>
      <div className="mt-6 space-y-6">{children}</div>
    </div>
  );
}