import { Link } from "@tanstack/react-router";
import { Play } from "lucide-react";
import type { Playlist } from "@/lib/types";
import { useMusic } from "@/lib/music-store";

export function PlaylistCard({ playlist }: { playlist: Playlist }) {
  const { loadAndPlay } = useMusic();
  const hue = (playlist.name.charCodeAt(0) * 7) % 360;
  return (
    <Link
      to="/playlists/$id"
      params={{ id: playlist.id }}
      className="group glass relative flex flex-col gap-3 rounded-xl p-4 transition-all hover:-translate-y-1 hover:bg-white/[0.08]"
    >
      <div className="relative">
        <div className="cover-art aspect-square w-full rounded-lg shadow-card" style={{ ["--cover-hue" as string]: hue }} />
        <button
          onClick={(e) => {
            e.preventDefault();
            if (playlist.songIds.length) loadAndPlay(playlist.songIds, playlist.songIds[0]);
          }}
          className="absolute bottom-2 right-2 grid h-11 w-11 translate-y-2 place-items-center rounded-full bg-gradient-brand text-brand-foreground opacity-0 shadow-glow transition-all group-hover:translate-y-0 group-hover:opacity-100"
          aria-label="Play"
        >
          <Play className="ml-0.5 h-5 w-5 fill-current" />
        </button>
      </div>
      <div className="min-w-0">
        <div className="truncate font-semibold">{playlist.name}</div>
        <div className="truncate text-xs text-muted-foreground">
          {playlist.description ?? `${playlist.songIds.length} tracks`}
        </div>
      </div>
    </Link>
  );
}