/**
 * DSA library for the Music Playlist Manager.
 *
 * Every structure below is annotated with:
 *   - WHY it fits the music use-case
 *   - Time complexity for its main operations
 *   - Space complexity
 *
 * These implementations are intentionally hand-written (not just calls into
 * standard library helpers) so they can be presented as part of a college
 * DSA project.
 */

// ---------- Doubly Linked List (playlist order) ----------
// WHY: Playlists frequently need O(1) insertions/removals in the middle
// (drag-to-reorder, remove song) and bi-directional traversal (prev/next).
// TIME:  insert/remove given node = O(1), traversal = O(n)
// SPACE: O(n)
export class DLLNode<T> {
  prev: DLLNode<T> | null = null;
  next: DLLNode<T> | null = null;
  constructor(public value: T) {}
}
export class DoublyLinkedList<T> {
  head: DLLNode<T> | null = null;
  tail: DLLNode<T> | null = null;
  size = 0;
  push(value: T): DLLNode<T> {
    const node = new DLLNode(value);
    if (!this.tail) { this.head = this.tail = node; }
    else { node.prev = this.tail; this.tail.next = node; this.tail = node; }
    this.size++;
    return node;
  }
  toArray(): T[] {
    const out: T[] = [];
    for (let n = this.head; n; n = n.next) out.push(n.value);
    return out;
  }
}

// ---------- Stack (Undo history) ----------
// WHY: Undo is a Last-In-First-Out operation — perfect fit for a stack.
// TIME: push/pop/peek = O(1)   SPACE: O(n)
export class Stack<T> {
  private data: T[] = [];
  push(v: T) { this.data.push(v); }
  pop(): T | undefined { return this.data.pop(); }
  peek(): T | undefined { return this.data[this.data.length - 1]; }
  get size() { return this.data.length; }
  clear() { this.data = []; }
  toArray() { return [...this.data]; }
}

// ---------- Queue (Play-Next queue) ----------
// WHY: "Play next" is First-In-First-Out — the song queued first plays first.
// TIME: enqueue/dequeue = O(1) amortised   SPACE: O(n)
export class Queue<T> {
  private data: T[] = [];
  enqueue(v: T) { this.data.push(v); }
  dequeue(): T | undefined { return this.data.shift(); }
  get size() { return this.data.length; }
  toArray() { return [...this.data]; }
  clear() { this.data = []; }
}

// ---------- Circular Queue (Repeat playlist) ----------
// WHY: Repeat mode = looping through songs; the tail wraps to the head.
// TIME: next/prev = O(1)   SPACE: O(n)
export class CircularQueue<T> {
  private idx = 0;
  constructor(private items: T[] = []) {}
  setItems(items: T[]) { this.items = items; this.idx = 0; }
  current(): T | undefined { return this.items[this.idx]; }
  next(): T | undefined {
    if (!this.items.length) return undefined;
    this.idx = (this.idx + 1) % this.items.length;
    return this.current();
  }
  prev(): T | undefined {
    if (!this.items.length) return undefined;
    this.idx = (this.idx - 1 + this.items.length) % this.items.length;
    return this.current();
  }
  jumpTo(i: number) { if (this.items.length) this.idx = ((i % this.items.length) + this.items.length) % this.items.length; }
}

// ---------- Hash Map (Fast song lookup by id) ----------
// WHY: O(1) average lookup instead of scanning the array every time.
// TIME: get/set/delete = O(1) avg, O(n) worst   SPACE: O(n)
// (We wrap Map to make the DSA usage explicit.)
export class HashMap<K, V> {
  private m = new Map<K, V>();
  set(k: K, v: V) { this.m.set(k, v); return this; }
  get(k: K) { return this.m.get(k); }
  has(k: K) { return this.m.has(k); }
  delete(k: K) { return this.m.delete(k); }
  get size() { return this.m.size; }
  values() { return [...this.m.values()]; }
}

// ---------- Binary Search ----------
// WHY: When songs are sorted by name, we can find matches in O(log n).
// TIME: O(log n)   SPACE: O(1)
export function binarySearch<T>(arr: T[], target: string, key: (t: T) => string): number {
  let lo = 0, hi = arr.length - 1;
  const t = target.toLowerCase();
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const v = key(arr[mid]).toLowerCase();
    if (v === t) return mid;
    if (v < t) lo = mid + 1;
    else hi = mid - 1;
  }
  return -1;
}

// ---------- Merge Sort (Sort playlists stably) ----------
// WHY: Guaranteed O(n log n), stable — good when secondary ordering matters.
// TIME: O(n log n)   SPACE: O(n)
export function mergeSort<T>(arr: T[], cmp: (a: T, b: T) => number): T[] {
  if (arr.length <= 1) return arr.slice();
  const mid = arr.length >> 1;
  const left = mergeSort(arr.slice(0, mid), cmp);
  const right = mergeSort(arr.slice(mid), cmp);
  const out: T[] = [];
  let i = 0, j = 0;
  while (i < left.length && j < right.length) {
    out.push(cmp(left[i], right[j]) <= 0 ? left[i++] : right[j++]);
  }
  return out.concat(left.slice(i)).concat(right.slice(j));
}

// ---------- Quick Sort (Sort by rating) ----------
// WHY: In-place, cache-friendly, fastest on random data in practice.
// TIME: O(n log n) avg, O(n^2) worst   SPACE: O(log n) recursion
export function quickSort<T>(arr: T[], cmp: (a: T, b: T) => number): T[] {
  const a = arr.slice();
  const go = (lo: number, hi: number) => {
    if (lo >= hi) return;
    const pivot = a[(lo + hi) >> 1];
    let i = lo, j = hi;
    while (i <= j) {
      while (cmp(a[i], pivot) < 0) i++;
      while (cmp(a[j], pivot) > 0) j--;
      if (i <= j) { [a[i], a[j]] = [a[j], a[i]]; i++; j--; }
    }
    go(lo, j); go(i, hi);
  };
  go(0, a.length - 1);
  return a;
}

// ---------- Max-Heap / Priority Queue (Top-rated songs) ----------
// WHY: Efficiently extract the K highest-rated songs.
// TIME: push/pop = O(log n), peek = O(1)   SPACE: O(n)
export class MaxHeap<T> {
  private h: T[] = [];
  constructor(private cmp: (a: T, b: T) => number) {}
  get size() { return this.h.length; }
  peek(): T | undefined { return this.h[0]; }
  push(v: T) {
    this.h.push(v);
    let i = this.h.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.cmp(this.h[i], this.h[p]) > 0) {
        [this.h[i], this.h[p]] = [this.h[p], this.h[i]]; i = p;
      } else break;
    }
  }
  pop(): T | undefined {
    if (!this.h.length) return undefined;
    const top = this.h[0];
    const last = this.h.pop()!;
    if (this.h.length) {
      this.h[0] = last;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1, r = 2 * i + 2; let best = i;
        if (l < this.h.length && this.cmp(this.h[l], this.h[best]) > 0) best = l;
        if (r < this.h.length && this.cmp(this.h[r], this.h[best]) > 0) best = r;
        if (best === i) break;
        [this.h[i], this.h[best]] = [this.h[best], this.h[i]]; i = best;
      }
    }
    return top;
  }
  topK(k: number): T[] {
    const clone = new MaxHeap<T>(this.cmp);
    clone.h = [...this.h];
    const out: T[] = [];
    while (out.length < k && clone.size) out.push(clone.pop()!);
    return out;
  }
}

// ---------- Genre / Album Tree ----------
// WHY: Genres → Artists → Albums forms a natural hierarchy; a tree lets us
//      browse and aggregate at any level.
// TIME: insert = O(1) per node   SPACE: O(n)
export interface TreeNode {
  name: string;
  children: Map<string, TreeNode>;
  count: number;
}
export function makeTreeNode(name: string): TreeNode {
  return { name, children: new Map(), count: 0 };
}
export function insertPath(root: TreeNode, path: string[]) {
  let node = root;
  node.count++;
  for (const seg of path) {
    if (!node.children.has(seg)) node.children.set(seg, makeTreeNode(seg));
    node = node.children.get(seg)!;
    node.count++;
  }
}

// ---------- Graph (Song recommendations) ----------
// WHY: Songs share artists/genres. Modelling songs as nodes with edges
//      weighted by similarity lets us recommend related tracks via BFS.
// TIME: BFS = O(V + E)   SPACE: O(V + E)
export class Graph<T> {
  private adj = new Map<T, Map<T, number>>();
  addNode(v: T) { if (!this.adj.has(v)) this.adj.set(v, new Map()); }
  addEdge(a: T, b: T, weight = 1) {
    this.addNode(a); this.addNode(b);
    this.adj.get(a)!.set(b, (this.adj.get(a)!.get(b) ?? 0) + weight);
    this.adj.get(b)!.set(a, (this.adj.get(b)!.get(a) ?? 0) + weight);
  }
  neighbors(v: T): Array<{ node: T; weight: number }> {
    return [...(this.adj.get(v)?.entries() ?? [])].map(([node, weight]) => ({ node, weight }));
  }
  /** BFS-based recommendations ordered by cumulative edge weight. */
  recommend(seed: T, limit = 8): T[] {
    const scores = new Map<T, number>();
    const seen = new Set<T>([seed]);
    const q: T[] = [seed];
    while (q.length) {
      const cur = q.shift()!;
      for (const { node, weight } of this.neighbors(cur)) {
        scores.set(node, (scores.get(node) ?? 0) + weight);
        if (!seen.has(node)) { seen.add(node); q.push(node); }
      }
    }
    scores.delete(seed);
    return [...scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([n]) => n);
  }
}