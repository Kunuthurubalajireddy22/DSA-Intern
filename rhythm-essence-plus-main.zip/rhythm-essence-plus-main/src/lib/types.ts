export interface Song {
  id: string;
  name: string;
  artist: string;
  album: string;
  genre: string;
  duration: number; // seconds
  rating: number;   // 0-5
  favorite: boolean;
  coverHue: number; // used by CSS cover-art utility
  addedAt: number;  // epoch ms
}

export interface Playlist {
  id: string;
  name: string;
  description?: string;
  songIds: string[]; // order preserved (backed by DoublyLinkedList in memory)
  createdAt: number;
}

export type UndoAction =
  | { type: "delete-playlist"; playlist: Playlist }
  | { type: "remove-song"; playlistId: string; songId: string; index: number }
  | { type: "rename-playlist"; playlistId: string; prevName: string }
  | { type: "move-song"; playlistId: string; from: number; to: number }
  | { type: "delete-song"; song: Song };