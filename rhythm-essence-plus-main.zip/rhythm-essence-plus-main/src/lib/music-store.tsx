import {
  createContext, useContext, useEffect, useMemo, useReducer, useRef, useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import type { Playlist, Song, UndoAction } from "./types";
import { SAMPLE_PLAYLISTS, SAMPLE_SONGS } from "./sample-data";
import {
  CircularQueue, Graph, HashMap, MaxHeap, Queue, Stack,
  binarySearch, mergeSort, quickSort,
} from "./dsa";

// ---------------- Persistence ----------------
const STORAGE_KEY = "sonata.state.v1";

interface PersistedState {
  songs: Song[];
  playlists: Playlist[];
  favorites: string[];   // song ids
  recentPlays: string[]; // most-recent-first
  playCounts: Record<string, number>;
}

function loadState(): PersistedState {
  if (typeof window === "undefined") return empty();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return seed();
    return JSON.parse(raw) as PersistedState;
  } catch {
    return seed();
  }
}
function empty(): PersistedState {
  return { songs: [], playlists: [], favorites: [], recentPlays: [], playCounts: {} };
}
function seed(): PersistedState {
  return {
    songs: SAMPLE_SONGS,
    playlists: SAMPLE_PLAYLISTS,
    favorites: SAMPLE_SONGS.filter((s) => s.favorite).map((s) => s.id),
    recentPlays: [],
    playCounts: {},
  };
}

// ---------------- Reducer ----------------
type Action =
  | { type: "hydrate"; state: PersistedState }
  | { type: "add-song"; song: Song }
  | { type: "delete-song"; id: string }
  | { type: "update-song"; id: string; patch: Partial<Song> }
  | { type: "toggle-favorite"; id: string }
  | { type: "create-playlist"; playlist: Playlist }
  | { type: "delete-playlist"; id: string }
  | { type: "rename-playlist"; id: string; name: string }
  | { type: "duplicate-playlist"; id: string; newId: string }
  | { type: "add-song-to-playlist"; playlistId: string; songId: string }
  | { type: "remove-song-from-playlist"; playlistId: string; songId: string }
  | { type: "move-song"; playlistId: string; from: number; to: number }
  | { type: "record-play"; songId: string }
  | { type: "restore"; state: PersistedState };

function reducer(state: PersistedState, a: Action): PersistedState {
  switch (a.type) {
    case "hydrate":
    case "restore":
      return a.state;
    case "add-song":
      return { ...state, songs: [a.song, ...state.songs] };
    case "delete-song":
      return {
        ...state,
        songs: state.songs.filter((s) => s.id !== a.id),
        favorites: state.favorites.filter((id) => id !== a.id),
        playlists: state.playlists.map((p) => ({ ...p, songIds: p.songIds.filter((id) => id !== a.id) })),
      };
    case "update-song":
      return { ...state, songs: state.songs.map((s) => (s.id === a.id ? { ...s, ...a.patch } : s)) };
    case "toggle-favorite": {
      const isFav = state.favorites.includes(a.id);
      return {
        ...state,
        favorites: isFav ? state.favorites.filter((x) => x !== a.id) : [a.id, ...state.favorites],
        songs: state.songs.map((s) => (s.id === a.id ? { ...s, favorite: !isFav } : s)),
      };
    }
    case "create-playlist":
      return { ...state, playlists: [a.playlist, ...state.playlists] };
    case "delete-playlist":
      return { ...state, playlists: state.playlists.filter((p) => p.id !== a.id) };
    case "rename-playlist":
      return { ...state, playlists: state.playlists.map((p) => (p.id === a.id ? { ...p, name: a.name } : p)) };
    case "duplicate-playlist": {
      const src = state.playlists.find((p) => p.id === a.id);
      if (!src) return state;
      const copy: Playlist = { ...src, id: a.newId, name: `${src.name} (Copy)`, createdAt: Date.now() };
      return { ...state, playlists: [copy, ...state.playlists] };
    }
    case "add-song-to-playlist":
      return {
        ...state,
        playlists: state.playlists.map((p) =>
          p.id === a.playlistId && !p.songIds.includes(a.songId)
            ? { ...p, songIds: [...p.songIds, a.songId] }
            : p,
        ),
      };
    case "remove-song-from-playlist":
      return {
        ...state,
        playlists: state.playlists.map((p) =>
          p.id === a.playlistId ? { ...p, songIds: p.songIds.filter((id) => id !== a.songId) } : p,
        ),
      };
    case "move-song":
      return {
        ...state,
        playlists: state.playlists.map((p) => {
          if (p.id !== a.playlistId) return p;
          const arr = [...p.songIds];
          const [x] = arr.splice(a.from, 1);
          arr.splice(a.to, 0, x);
          return { ...p, songIds: arr };
        }),
      };
    case "record-play":
      return {
        ...state,
        recentPlays: [a.songId, ...state.recentPlays.filter((id) => id !== a.songId)].slice(0, 50),
        playCounts: { ...state.playCounts, [a.songId]: (state.playCounts[a.songId] ?? 0) + 1 },
      };
    default:
      return state;
  }
}

// ---------------- Context ----------------
export type SortKey = "name" | "artist" | "duration" | "rating" | "recent";
export interface PlayerState {
  currentId: string | null;
  playing: boolean;
  progress: number; // 0-1
  volume: number;   // 0-1
  shuffle: boolean;
  repeat: "off" | "all" | "one";
  queue: string[];      // upcoming (Queue DSA)
  playbackOrder: string[]; // songs currently loaded into the CircularQueue
}

interface MusicContextValue {
  state: PersistedState;
  // Song helpers
  songById: (id: string) => Song | undefined;
  addSong: (song: Omit<Song, "id" | "addedAt">) => void;
  deleteSong: (id: string) => void;
  updateSong: (id: string, patch: Partial<Song>) => void;
  toggleFavorite: (id: string) => void;
  // Playlist helpers
  createPlaylist: (name: string, description?: string) => string;
  deletePlaylist: (id: string) => void;
  renamePlaylist: (id: string, name: string) => void;
  duplicatePlaylist: (id: string) => void;
  addSongToPlaylist: (playlistId: string, songId: string) => void;
  removeSongFromPlaylist: (playlistId: string, songId: string) => void;
  movePlaylistSong: (playlistId: string, from: number, to: number) => void;
  // Undo
  undo: () => void;
  undoDepth: number;
  // Search / sort / filter
  searchSongs: (q: string, field?: "name" | "artist" | "album" | "genre" | "rating") => Song[];
  sortSongs: (songs: Song[], key: SortKey) => Song[];
  // Player
  player: PlayerState;
  loadAndPlay: (songIds: string[], startId?: string) => void;
  togglePlay: () => void;
  next: () => void;
  prev: () => void;
  setShuffle: (v: boolean) => void;
  cycleRepeat: () => void;
  setVolume: (v: number) => void;
  seek: (fraction: number) => void;
  enqueueNext: (songId: string) => void;
  // Derived
  mostPlayed: () => Song[];
  topRated: (k?: number) => Song[];
  recommendations: (seedId?: string) => Song[];
}

const MusicContext = createContext<MusicContextValue | null>(null);

export function MusicProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, () => (typeof window === "undefined" ? empty() : loadState()));

  // Hydrate on the client after SSR.
  useEffect(() => {
    const s = loadState();
    dispatch({ type: "hydrate", state: s });
  }, []);

  // Auto-save (localStorage).
  useEffect(() => {
    if (typeof window === "undefined") return;
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { /* ignore */ }
  }, [state]);

  // Undo stack (DSA: Stack).
  const undoStack = useRef(new Stack<{ action: UndoAction; before: PersistedState }>());
  const [undoDepth, setUndoDepth] = useState(0);
  const pushUndo = (action: UndoAction, before: PersistedState) => {
    undoStack.current.push({ action, before });
    setUndoDepth(undoStack.current.size);
  };
  const undo = () => {
    const entry = undoStack.current.pop();
    if (!entry) { toast("Nothing to undo"); return; }
    dispatch({ type: "restore", state: entry.before });
    setUndoDepth(undoStack.current.size);
    toast.success("Undone");
  };

  // ---------- Hash map for O(1) song lookup ----------
  const songMap = useMemo(() => {
    const m = new HashMap<string, Song>();
    state.songs.forEach((s) => m.set(s.id, s));
    return m;
  }, [state.songs]);
  const songById = (id: string) => songMap.get(id);

  // ---------- Recommendation graph ----------
  const graph = useMemo(() => {
    const g = new Graph<string>();
    state.songs.forEach((a) => {
      g.addNode(a.id);
      state.songs.forEach((b) => {
        if (a.id === b.id) return;
        let w = 0;
        if (a.artist === b.artist) w += 3;
        if (a.genre === b.genre) w += 2;
        if (a.album === b.album) w += 4;
        if (w > 0) g.addEdge(a.id, b.id, w);
      });
    });
    return g;
  }, [state.songs]);

  // ---------- Player ----------
  const [player, setPlayer] = useState<PlayerState>({
    currentId: null, playing: false, progress: 0, volume: 0.8,
    shuffle: false, repeat: "off", queue: [], playbackOrder: [],
  });
  const circular = useRef(new CircularQueue<string>([]));
  const upNext = useRef(new Queue<string>());

  // Simulated playback timer (no real audio in this template).
  useEffect(() => {
    if (!player.playing || !player.currentId) return;
    const song = songById(player.currentId);
    if (!song) return;
    const totalMs = song.duration * 1000;
    const start = performance.now() - player.progress * totalMs;
    const id = window.setInterval(() => {
      const elapsed = performance.now() - start;
      let p = Math.min(1, elapsed / totalMs);
      setPlayer((s) => ({ ...s, progress: p }));
      if (p >= 1) {
        window.clearInterval(id);
        handleTrackEnd();
      }
    }, 250);
    return () => window.clearInterval(id);
     
  }, [player.playing, player.currentId]);

  const handleTrackEnd = () => {
    if (player.repeat === "one" && player.currentId) {
      setPlayer((s) => ({ ...s, progress: 0 }));
      return;
    }
    next();
  };

  const loadAndPlay = (songIds: string[], startId?: string) => {
    if (!songIds.length) return;
    circular.current.setItems(songIds);
    if (startId) circular.current.jumpTo(songIds.indexOf(startId));
    const currentId = circular.current.current()!;
    dispatch({ type: "record-play", songId: currentId });
    setPlayer((s) => ({ ...s, currentId, playing: true, progress: 0, playbackOrder: songIds }));
  };
  const togglePlay = () => setPlayer((s) => ({ ...s, playing: !s.playing }));
  const next = () => {
    // Play-Next queue takes priority (DSA: Queue)
    const nextFromQueue = upNext.current.dequeue();
    if (nextFromQueue) {
      dispatch({ type: "record-play", songId: nextFromQueue });
      setPlayer((s) => ({ ...s, currentId: nextFromQueue, playing: true, progress: 0, queue: upNext.current.toArray() }));
      return;
    }
    let id: string | undefined;
    if (player.shuffle && player.playbackOrder.length) {
      const pool = player.playbackOrder.filter((x) => x !== player.currentId);
      id = pool[Math.floor(Math.random() * pool.length)];
      circular.current.jumpTo(player.playbackOrder.indexOf(id!));
    } else {
      id = circular.current.next();
      if (!id) return;
      if (player.repeat === "off" && player.playbackOrder.indexOf(id) === 0) {
        setPlayer((s) => ({ ...s, playing: false, progress: 0 }));
        return;
      }
    }
    dispatch({ type: "record-play", songId: id });
    setPlayer((s) => ({ ...s, currentId: id!, playing: true, progress: 0 }));
  };
  const prev = () => {
    const id = circular.current.prev();
    if (!id) return;
    dispatch({ type: "record-play", songId: id });
    setPlayer((s) => ({ ...s, currentId: id, playing: true, progress: 0 }));
  };
  const setShuffle = (v: boolean) => setPlayer((s) => ({ ...s, shuffle: v }));
  const cycleRepeat = () =>
    setPlayer((s) => ({ ...s, repeat: s.repeat === "off" ? "all" : s.repeat === "all" ? "one" : "off" }));
  const setVolume = (v: number) => setPlayer((s) => ({ ...s, volume: v }));
  const seek = (f: number) => setPlayer((s) => ({ ...s, progress: Math.max(0, Math.min(1, f)) }));
  const enqueueNext = (id: string) => {
    upNext.current.enqueue(id);
    setPlayer((s) => ({ ...s, queue: upNext.current.toArray() }));
    toast.success("Added to Play Next");
  };

  // ---------- Search (Binary Search over sorted names + linear across other fields) ----------
  const searchSongs = (q: string, field: "name" | "artist" | "album" | "genre" | "rating" = "name"): Song[] => {
    const query = q.trim();
    if (!query) return state.songs;
    if (field === "rating") {
      const target = Number(query);
      return state.songs.filter((s) => s.rating === target);
    }
    if (field === "name") {
      const sorted = mergeSort(state.songs, (a, b) => a.name.localeCompare(b.name));
      const hit = binarySearch(sorted, query, (s) => s.name);
      if (hit !== -1) return [sorted[hit]];
      return sorted.filter((s) => s.name.toLowerCase().includes(query.toLowerCase()));
    }
    const key = field;
    return state.songs.filter((s) => (s[key] as string).toLowerCase().includes(query.toLowerCase()));
  };

  // ---------- Sorting (Merge Sort / Quick Sort) ----------
  const sortSongs = (songs: Song[], key: SortKey): Song[] => {
    switch (key) {
      case "name":     return mergeSort(songs, (a, b) => a.name.localeCompare(b.name));
      case "artist":   return mergeSort(songs, (a, b) => a.artist.localeCompare(b.artist));
      case "duration": return mergeSort(songs, (a, b) => a.duration - b.duration);
      case "rating":   return quickSort(songs, (a, b) => b.rating - a.rating);
      case "recent":   return mergeSort(songs, (a, b) => b.addedAt - a.addedAt);
    }
  };

  const mostPlayed = () =>
    Object.entries(state.playCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([id]) => songById(id))
      .filter(Boolean) as Song[];

  const topRated = (k = 6) => {
    // MaxHeap for O(n log k) top-k retrieval.
    const heap = new MaxHeap<Song>((a, b) => a.rating - b.rating);
    state.songs.forEach((s) => heap.push(s));
    return heap.topK(k);
  };

  const recommendations = (seedId?: string): Song[] => {
    const seed = seedId ?? state.favorites[0] ?? state.songs[0]?.id;
    if (!seed) return [];
    return graph.recommend(seed, 8).map((id) => songById(id)!).filter(Boolean);
  };

  // ---------- Mutations that record undo ----------
  const addSong: MusicContextValue["addSong"] = (song) => {
    const full: Song = { ...song, id: `s${Date.now().toString(36)}`, addedAt: Date.now() };
    pushUndo({ type: "delete-song", song: full }, state);
    dispatch({ type: "add-song", song: full });
    toast.success(`Added "${full.name}"`);
  };
  const deleteSong: MusicContextValue["deleteSong"] = (id) => {
    const song = songById(id);
    if (!song) return;
    pushUndo({ type: "delete-song", song }, state);
    dispatch({ type: "delete-song", id });
    toast(`Removed "${song.name}"`, { action: { label: "Undo", onClick: undo } });
  };
  const updateSong: MusicContextValue["updateSong"] = (id, patch) => {
    pushUndo({ type: "delete-song", song: songById(id)! }, state);
    dispatch({ type: "update-song", id, patch });
  };
  const toggleFavorite: MusicContextValue["toggleFavorite"] = (id) => {
    dispatch({ type: "toggle-favorite", id });
  };

  const createPlaylist: MusicContextValue["createPlaylist"] = (name, description) => {
    const id = `p${Date.now().toString(36)}`;
    const playlist: Playlist = { id, name, description, songIds: [], createdAt: Date.now() };
    pushUndo({ type: "delete-playlist", playlist }, state);
    dispatch({ type: "create-playlist", playlist });
    toast.success(`Playlist "${name}" created`);
    return id;
  };
  const deletePlaylist: MusicContextValue["deletePlaylist"] = (id) => {
    const playlist = state.playlists.find((p) => p.id === id);
    if (!playlist) return;
    pushUndo({ type: "delete-playlist", playlist }, state);
    dispatch({ type: "delete-playlist", id });
    toast(`Deleted "${playlist.name}"`, { action: { label: "Undo", onClick: undo } });
  };
  const renamePlaylist: MusicContextValue["renamePlaylist"] = (id, name) => {
    const prev = state.playlists.find((p) => p.id === id);
    if (!prev) return;
    pushUndo({ type: "rename-playlist", playlistId: id, prevName: prev.name }, state);
    dispatch({ type: "rename-playlist", id, name });
  };
  const duplicatePlaylist: MusicContextValue["duplicatePlaylist"] = (id) => {
    const newId = `p${Date.now().toString(36)}`;
    pushUndo({ type: "delete-playlist", playlist: { ...(state.playlists.find((p) => p.id === id)!), id: newId } }, state);
    dispatch({ type: "duplicate-playlist", id, newId });
    toast.success("Playlist duplicated");
  };
  const addSongToPlaylist: MusicContextValue["addSongToPlaylist"] = (playlistId, songId) => {
    pushUndo({ type: "remove-song", playlistId, songId, index: -1 }, state);
    dispatch({ type: "add-song-to-playlist", playlistId, songId });
  };
  const removeSongFromPlaylist: MusicContextValue["removeSongFromPlaylist"] = (playlistId, songId) => {
    pushUndo({ type: "remove-song", playlistId, songId, index: -1 }, state);
    dispatch({ type: "remove-song-from-playlist", playlistId, songId });
  };
  const movePlaylistSong: MusicContextValue["movePlaylistSong"] = (playlistId, from, to) => {
    pushUndo({ type: "move-song", playlistId, from: to, to: from }, state);
    dispatch({ type: "move-song", playlistId, from, to });
  };

  const value: MusicContextValue = {
    state, songById,
    addSong, deleteSong, updateSong, toggleFavorite,
    createPlaylist, deletePlaylist, renamePlaylist, duplicatePlaylist,
    addSongToPlaylist, removeSongFromPlaylist, movePlaylistSong,
    undo, undoDepth,
    searchSongs, sortSongs,
    player, loadAndPlay, togglePlay, next, prev, setShuffle, cycleRepeat, setVolume, seek, enqueueNext,
    mostPlayed, topRated, recommendations,
  };

  return <MusicContext.Provider value={value}>{children}</MusicContext.Provider>;
}

export function useMusic(): MusicContextValue {
  const ctx = useContext(MusicContext);
  if (!ctx) throw new Error("useMusic must be used inside <MusicProvider>");
  return ctx;
}

// Utility: format seconds -> mm:ss
export function fmtDuration(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${r.toString().padStart(2, "0")}`;
}