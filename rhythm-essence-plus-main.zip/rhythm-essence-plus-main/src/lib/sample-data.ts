import type { Song } from "./types";

// A curated fake catalogue. Durations are in seconds, ratings 0–5.
// Album covers are rendered via CSS from `coverHue` — no external assets.
export const SAMPLE_SONGS: Song[] = [
  { id: "s1",  name: "Midnight Drive",       artist: "Neon Skyline",    album: "After Hours",      genre: "Synthwave",  duration: 214, rating: 5, favorite: true,  coverHue: 275, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 2 },
  { id: "s2",  name: "Ocean Static",         artist: "Neon Skyline",    album: "After Hours",      genre: "Synthwave",  duration: 198, rating: 4, favorite: false, coverHue: 210, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 3 },
  { id: "s3",  name: "Golden Hour",          artist: "Sable Rose",      album: "Warm Analog",      genre: "Indie",      duration: 232, rating: 5, favorite: true,  coverHue: 40,  addedAt: Date.now() - 1000 * 60 * 60 * 24 * 1 },
  { id: "s4",  name: "Paper Planes",         artist: "Sable Rose",      album: "Warm Analog",      genre: "Indie",      duration: 187, rating: 4, favorite: false, coverHue: 25,  addedAt: Date.now() - 1000 * 60 * 60 * 24 * 5 },
  { id: "s5",  name: "Concrete Symphony",    artist: "Halcyon Grove",   album: "City Lights",      genre: "Alt Rock",   duration: 265, rating: 4, favorite: false, coverHue: 0,   addedAt: Date.now() - 1000 * 60 * 60 * 24 * 6 },
  { id: "s6",  name: "Static Bloom",         artist: "Halcyon Grove",   album: "City Lights",      genre: "Alt Rock",   duration: 241, rating: 3, favorite: false, coverHue: 340, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 7 },
  { id: "s7",  name: "Velvet Sky",           artist: "Marlow Reed",     album: "Late Bloom",       genre: "Jazz",       duration: 302, rating: 5, favorite: true,  coverHue: 305, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 4 },
  { id: "s8",  name: "Slow Dial",            artist: "Marlow Reed",     album: "Late Bloom",       genre: "Jazz",       duration: 278, rating: 4, favorite: false, coverHue: 285, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 9 },
  { id: "s9",  name: "Pulse Grid",           artist: "Cassia Wave",     album: "Signal Path",      genre: "Electronic", duration: 226, rating: 5, favorite: true,  coverHue: 175, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 8 },
  { id: "s10", name: "Cinder Field",         artist: "Cassia Wave",     album: "Signal Path",      genre: "Electronic", duration: 244, rating: 4, favorite: false, coverHue: 155, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 10 },
  { id: "s11", name: "Paper Compass",        artist: "The Alders",      album: "Northbound",       genre: "Folk",       duration: 205, rating: 3, favorite: false, coverHue: 90,  addedAt: Date.now() - 1000 * 60 * 60 * 24 * 12 },
  { id: "s12", name: "Hollow Wind",          artist: "The Alders",      album: "Northbound",       genre: "Folk",       duration: 219, rating: 4, favorite: true,  coverHue: 110, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 11 },
  { id: "s13", name: "Chromatic",            artist: "Kaia Vestra",     album: "Prism",            genre: "Pop",        duration: 189, rating: 5, favorite: true,  coverHue: 320, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 14 },
  { id: "s14", name: "Neon Cathedral",       artist: "Kaia Vestra",     album: "Prism",            genre: "Pop",        duration: 210, rating: 4, favorite: false, coverHue: 240, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 15 },
  { id: "s15", name: "After Rain",           artist: "Yuki Ando",       album: "Quiet Rooms",      genre: "Ambient",    duration: 348, rating: 5, favorite: true,  coverHue: 195, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 16 },
  { id: "s16", name: "Paper Lanterns",       artist: "Yuki Ando",       album: "Quiet Rooms",      genre: "Ambient",    duration: 312, rating: 4, favorite: false, coverHue: 220, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 20 },
  { id: "s17", name: "Wildcard",             artist: "Orion Park",      album: "Suits & Sirens",   genre: "Hip-Hop",    duration: 198, rating: 4, favorite: false, coverHue: 15,  addedAt: Date.now() - 1000 * 60 * 60 * 24 * 22 },
  { id: "s18", name: "Blueprint",            artist: "Orion Park",      album: "Suits & Sirens",   genre: "Hip-Hop",    duration: 214, rating: 5, favorite: true,  coverHue: 260, addedAt: Date.now() - 1000 * 60 * 60 * 24 * 25 },
];

export const SAMPLE_PLAYLISTS = [
  { id: "p1", name: "Late Night Drive",   description: "For empty highways at 2am.",     songIds: ["s1","s2","s9","s10","s5","s14"], createdAt: Date.now() - 1000 * 60 * 60 * 24 * 3 },
  { id: "p2", name: "Golden Mornings",    description: "Sunrise, coffee, unhurried.",     songIds: ["s3","s4","s11","s12","s15","s16"], createdAt: Date.now() - 1000 * 60 * 60 * 24 * 5 },
  { id: "p3", name: "Deep Focus",         description: "Instrumental & ambient.",         songIds: ["s7","s8","s15","s16","s9"], createdAt: Date.now() - 1000 * 60 * 60 * 24 * 8 },
];