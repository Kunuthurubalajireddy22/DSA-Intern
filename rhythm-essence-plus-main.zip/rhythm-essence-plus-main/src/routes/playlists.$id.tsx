import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { Copy, Pencil, Play, Trash2, Undo2 } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { AlbumCover } from "@/components/AlbumCover";
import { SongRow, SongTableHeader } from "@/components/SongRow";
import { useMusic, fmtDuration } from "@/lib/music-store";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Popover, PopoverContent, PopoverTrigger,
} from "@/components/ui/popover";

export const Route = createFileRoute("/playlists/$id")({
  component: PlaylistDetail,
});

function PlaylistDetail() {
  const { id } = useParams({ from: "/playlists/$id" });
  const navigate = useNavigate();
  const {
    state, songById, loadAndPlay, renamePlaylist, deletePlaylist, duplicatePlaylist,
    movePlaylistSong, undo, undoDepth, addSongToPlaylist,
  } = useMusic();

  const playlist = state.playlists.find((p) => p.id === id);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(playlist?.name ?? "");
  const dragFrom = useRef<number | null>(null);

  const songs = useMemo(() => (playlist?.songIds ?? []).map((sid) => songById(sid)).filter(Boolean) as NonNullable<ReturnType<typeof songById>>[], [playlist, songById]);
  const totalDuration = songs.reduce((n, s) => n + s.duration, 0);
  const hue = playlist ? (playlist.name.charCodeAt(0) * 7) % 360 : 152;
  const available = state.songs.filter((s) => !playlist?.songIds.includes(s.id));

  if (!playlist) {
    return <div className="glass rounded-2xl p-8 text-center">Playlist not found.</div>;
  }

  return (
    <div className="animate-float-in">
      <div
        className="relative flex flex-col items-start gap-6 overflow-hidden rounded-2xl p-6 md:flex-row md:items-end md:p-10"
        style={{ background: `linear-gradient(135deg, oklch(0.40 0.18 ${hue}) 0%, oklch(0.18 0.05 ${hue + 30}) 100%)` }}
      >
        <AlbumCover hue={hue} size={192} className="shadow-glow" />
        <div className="flex-1">
          <div className="text-xs font-semibold uppercase tracking-widest text-white/70">Playlist</div>
          {editing ? (
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              onBlur={() => { if (name.trim()) renamePlaylist(id, name.trim()); setEditing(false); }}
              onKeyDown={(e) => { if (e.key === "Enter") { if (name.trim()) renamePlaylist(id, name.trim()); setEditing(false); } }}
              className="mt-1 w-full max-w-lg rounded-md border border-white/20 bg-white/10 px-2 py-1 text-3xl font-bold outline-none md:text-5xl"
            />
          ) : (
            <h1 className="mt-1 text-3xl font-bold md:text-5xl">{playlist.name}</h1>
          )}
          {playlist.description && <p className="mt-2 max-w-2xl text-sm text-white/80">{playlist.description}</p>}
          <div className="mt-3 text-xs text-white/70">
            {songs.length} songs · {fmtDuration(totalDuration)}
          </div>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          onClick={() => songs.length && loadAndPlay(songs.map((s) => s.id))}
          className="flex items-center gap-2 rounded-full bg-gradient-brand px-5 py-2.5 font-semibold text-brand-foreground shadow-glow transition-transform hover:scale-105"
        >
          <Play className="h-4 w-4 fill-current" /> Play
        </button>
        <button
          onClick={() => { setName(playlist.name); setEditing(true); }}
          className="glass flex items-center gap-2 rounded-full px-4 py-2 text-sm"
        >
          <Pencil className="h-4 w-4" /> Rename
        </button>
        <button onClick={() => duplicatePlaylist(id)} className="glass flex items-center gap-2 rounded-full px-4 py-2 text-sm">
          <Copy className="h-4 w-4" /> Duplicate
        </button>
        <button
          onClick={() => { deletePlaylist(id); navigate({ to: "/" }); }}
          className="glass flex items-center gap-2 rounded-full px-4 py-2 text-sm text-destructive"
        >
          <Trash2 className="h-4 w-4" /> Delete
        </button>
        <Popover>
          <PopoverTrigger asChild>
            <button className="glass rounded-full px-4 py-2 text-sm">+ Add songs</button>
          </PopoverTrigger>
          <PopoverContent align="start" className="glass-strong max-h-80 w-80 overflow-y-auto border-white/10">
            {available.length === 0 ? (
              <div className="text-sm text-muted-foreground">Every song is already in this playlist.</div>
            ) : (
              <ul className="space-y-1">
                {available.map((s) => (
                  <li key={s.id}>
                    <button
                      onClick={() => addSongToPlaylist(id, s.id)}
                      className="flex w-full items-center gap-2 rounded-md p-2 text-left hover:bg-white/5"
                    >
                      <AlbumCover hue={s.coverHue} size={32} />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm">{s.name}</div>
                        <div className="truncate text-xs text-muted-foreground">{s.artist}</div>
                      </div>
                      <span className="text-xs text-muted-foreground">+</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </PopoverContent>
        </Popover>
        {undoDepth > 0 && (
          <button onClick={undo} className="glass ml-auto flex items-center gap-2 rounded-full px-4 py-2 text-sm">
            <Undo2 className="h-4 w-4" /> Undo ({undoDepth})
          </button>
        )}
      </div>

      <div className="glass mt-6 rounded-2xl p-4 md:p-6">
        <SongTableHeader />
        {songs.length === 0 ? (
          <div className="py-12 text-center text-sm text-muted-foreground">No songs yet — add some above.</div>
        ) : (
          <div className="space-y-1">
            {songs.map((s, i) => (
              <div
                key={s.id}
                draggable
                onDragStart={() => { dragFrom.current = i; }}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => {
                  const from = dragFrom.current;
                  if (from !== null && from !== i) movePlaylistSong(id, from, i);
                  dragFrom.current = null;
                }}
                className="cursor-grab active:cursor-grabbing"
              >
                <SongRow index={i} song={s} playlistId={id} contextIds={songs.map((x) => x.id)} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Suppress unused imports (kept for future features).
void Dialog; void DialogContent; void DialogFooter; void DialogHeader; void DialogTitle; void DialogTrigger; void Input; void Button;