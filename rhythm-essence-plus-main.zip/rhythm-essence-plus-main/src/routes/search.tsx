import { createFileRoute } from "@tanstack/react-router";
import { Search as SearchIcon } from "lucide-react";
import { useMemo, useState } from "react";
import { PageShell } from "@/components/PageShell";
import { SongRow, SongTableHeader } from "@/components/SongRow";
import { useMusic } from "@/lib/music-store";

export const Route = createFileRoute("/search")({
  head: () => ({ meta: [{ title: "Search — Sonata" }, { name: "description", content: "Search songs by name (binary search), artist, album, genre, or rating." }] }),
  component: SearchPage,
});

type Field = "name" | "artist" | "album" | "genre" | "rating";

function SearchPage() {
  const { state, searchSongs } = useMusic();
  const [q, setQ] = useState("");
  const [field, setField] = useState<Field>("name");

  const results = useMemo(() => (q ? searchSongs(q, field) : []), [q, field, searchSongs]);

  const suggestions = useMemo(() => {
    if (!q) return [];
    const l = q.toLowerCase();
    const set = new Set<string>();
    state.songs.forEach((s) => {
      [s.name, s.artist, s.album, s.genre].forEach((v) => {
        if (v.toLowerCase().includes(l)) set.add(v);
      });
    });
    return [...set].slice(0, 6);
  }, [q, state.songs]);

  return (
    <PageShell
      eyebrow="Find anything"
      title="Search your library"
      subtitle="By name we use binary search over a merge-sorted array — everything else falls back to a linear scan with substring match."
      hue={305}
    >
      <div className="glass sticky top-0 z-10 rounded-2xl p-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-center">
          <div className="relative flex-1">
            <SearchIcon className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              autoFocus
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search songs, artists, albums…"
              className="w-full rounded-full border border-white/10 bg-white/5 py-3 pl-11 pr-4 text-sm outline-none transition-all placeholder:text-muted-foreground focus:border-brand focus:bg-white/10 focus:ring-2 focus:ring-brand/30"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {(["name", "artist", "album", "genre", "rating"] as Field[]).map((f) => (
              <button
                key={f}
                onClick={() => setField(f)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium capitalize transition-all ${
                  field === f ? "bg-gradient-brand text-brand-foreground shadow-glow" : "bg-white/5 text-muted-foreground hover:bg-white/10"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        {q && suggestions.length > 0 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button
                key={s}
                onClick={() => setQ(s)}
                className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="glass rounded-2xl p-4 md:p-6">
        {!q ? (
          <div className="py-12 text-center text-sm text-muted-foreground">Type to search…</div>
        ) : results.length === 0 ? (
          <div className="py-12 text-center text-sm text-muted-foreground">No results for "{q}"</div>
        ) : (
          <>
            <div className="mb-3 text-xs text-muted-foreground">{results.length} result{results.length === 1 ? "" : "s"}</div>
            <SongTableHeader />
            <div className="space-y-1">
              {results.map((s, i) => (
                <SongRow key={s.id} index={i} song={s} contextIds={results.map((x) => x.id)} />
              ))}
            </div>
          </>
        )}
      </div>
    </PageShell>
  );
}