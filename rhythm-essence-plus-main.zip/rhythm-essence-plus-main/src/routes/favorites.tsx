import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { SongRow, SongTableHeader } from "@/components/SongRow";
import { useMusic } from "@/lib/music-store";

export const Route = createFileRoute("/favorites")({
  head: () => ({ meta: [{ title: "Favorites — Sonata" }, { name: "description", content: "Your favorite songs, always one tap away." }] }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const { state, songById } = useMusic();
  const songs = state.favorites.map((id) => songById(id)).filter(Boolean) as ReturnType<typeof songById>[] as NonNullable<ReturnType<typeof songById>>[];

  return (
    <PageShell eyebrow="Made with ♥" title="Favorites" subtitle={`${songs.length} songs you love.`} hue={340}>
      <div className="glass rounded-2xl p-4 md:p-6">
        {songs.length === 0 ? (
          <div className="py-12 text-center text-sm text-muted-foreground">Tap the heart on any song to add it here.</div>
        ) : (
          <>
            <SongTableHeader />
            <div className="space-y-1">
              {songs.map((s, i) => (
                <SongRow key={s.id} index={i} song={s} contextIds={songs.map((x) => x.id)} />
              ))}
            </div>
          </>
        )}
      </div>
    </PageShell>
  );
}