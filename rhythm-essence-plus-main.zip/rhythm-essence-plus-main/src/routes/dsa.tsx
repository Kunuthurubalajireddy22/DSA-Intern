import { createFileRoute } from "@tanstack/react-router";
import {
  Binary, GitBranch, Hash, Layers, ListOrdered, Network, RotateCcw, Search as SearchIcon,
  SortAsc, TreePine, Zap, Repeat,
} from "lucide-react";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/dsa")({
  head: () => ({ meta: [{ title: "DSA Explorer — Sonata" }, { name: "description", content: "Every data structure and algorithm used in Sonata, with its role, time complexity, and space complexity." }] }),
  component: DsaPage,
});

const items = [
  { Icon: Layers, name: "Array", where: "Song catalogue", why: "Indexed constant-time access into the master list of songs.", time: "access O(1), insert/remove O(n)", space: "O(n)" },
  { Icon: ListOrdered, name: "Doubly Linked List", where: "Playlist order", why: "O(1) insertions and removals when reordering songs; supports prev/next traversal.", time: "insert/remove O(1) given node, traversal O(n)", space: "O(n)" },
  { Icon: RotateCcw, name: "Stack", where: "Undo history", why: "Undo operations are Last-In-First-Out — a perfect fit for a stack.", time: "push/pop O(1)", space: "O(n)" },
  { Icon: ListOrdered, name: "Queue", where: "Play-Next queue", why: "First queued song plays first — classic FIFO behavior.", time: "enqueue/dequeue O(1)", space: "O(n)" },
  { Icon: Repeat, name: "Circular Queue", where: "Repeat playlist", why: "When repeat is on the last song wraps back to the first.", time: "next/prev O(1)", space: "O(n)" },
  { Icon: Hash, name: "Hash Map", where: "Song lookup by id", why: "Constant-time lookup instead of scanning the array for each render.", time: "get/set/delete O(1) avg", space: "O(n)" },
  { Icon: Binary, name: "Binary Search", where: "Search by name", why: "After merge-sorting by name we locate exact matches in log time.", time: "O(log n)", space: "O(1)" },
  { Icon: SortAsc, name: "Merge Sort", where: "Sort by name/artist/duration/recency", why: "Stable and guaranteed O(n log n) — preserves secondary ordering.", time: "O(n log n)", space: "O(n)" },
  { Icon: SortAsc, name: "Quick Sort", where: "Sort by rating", why: "In-place, cache-friendly, fastest in practice for the rating sort.", time: "O(n log n) avg, O(n²) worst", space: "O(log n) recursion" },
  { Icon: Zap, name: "Max-Heap / Priority Queue", where: "Top rated songs", why: "Extract top-K rated songs efficiently instead of a full sort.", time: "push/pop O(log n), peek O(1)", space: "O(n)" },
  { Icon: TreePine, name: "Tree", where: "Genre → Artist → Album hierarchy", why: "Natural nested browsing with per-node aggregate counts.", time: "insert O(depth)", space: "O(n)" },
  { Icon: Network, name: "Graph + BFS", where: "Recommendations", why: "Songs are nodes; edges weighted by shared artist/album/genre. BFS ranks similar tracks.", time: "BFS O(V + E)", space: "O(V + E)" },
];

export function DsaPage() {
  return (
    <PageShell
      eyebrow="Under the hood"
      title="DSA Explorer"
      subtitle="Every playlist action in Sonata is powered by a hand-written data structure or algorithm. Here is what is used and why — with time and space complexity."
      hue={172}
      actions={<a href="https://github.com" className="glass-strong rounded-full px-4 py-2 text-sm">View source</a>}
    >
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {items.map(({ Icon, name, where, why, time, space }) => (
          <div key={name} className="glass rounded-2xl p-5 transition-all hover:-translate-y-1 hover:bg-white/[0.08]">
            <div className="mb-3 flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-brand text-brand-foreground shadow-glow">
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <div className="font-bold">{name}</div>
                <div className="text-xs text-muted-foreground">{where}</div>
              </div>
            </div>
            <p className="mb-4 text-sm text-muted-foreground">{why}</p>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between border-t border-white/5 pt-2">
                <span className="text-muted-foreground">Time</span>
                <span className="font-mono text-foreground">{time}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Space</span>
                <span className="font-mono text-foreground">{space}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="mb-2 flex items-center gap-2">
          <GitBranch className="h-4 w-4 text-brand" /> <h3 className="text-lg font-bold">Where to read the code</h3>
        </div>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li><span className="text-foreground font-mono">src/lib/dsa/index.ts</span> — every structure & algorithm, heavily commented.</li>
          <li><span className="text-foreground font-mono">src/lib/music-store.tsx</span> — how each DSA plugs into playlists, search, sort, filter, and the player.</li>
          <li><span className="text-foreground font-mono">src/lib/types.ts</span> — the Song and Playlist data models.</li>
          <li><span className="text-foreground font-mono">src/lib/sample-data.ts</span> — the seed catalogue used at first launch.</li>
        </ul>
      </div>

      <div className="glass rounded-2xl p-6">
        <div className="mb-2"><SearchIcon className="mr-2 inline h-4 w-4 text-brand" /><span className="text-lg font-bold">Keyboard shortcuts</span></div>
        <div className="grid gap-2 text-sm md:grid-cols-2">
          <div className="flex justify-between"><span>Play / pause</span><kbd className="rounded bg-white/10 px-2 py-0.5 text-xs">Space</kbd></div>
          <div className="flex justify-between"><span>Next track</span><kbd className="rounded bg-white/10 px-2 py-0.5 text-xs">→</kbd></div>
          <div className="flex justify-between"><span>Previous track</span><kbd className="rounded bg-white/10 px-2 py-0.5 text-xs">←</kbd></div>
          <div className="flex justify-between"><span>Undo</span><kbd className="rounded bg-white/10 px-2 py-0.5 text-xs">Ctrl / ⌘ + Z</kbd></div>
        </div>
      </div>
    </PageShell>
  );
}