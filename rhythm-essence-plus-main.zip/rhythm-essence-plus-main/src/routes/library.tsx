import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageShell } from "@/components/PageShell";
import { SongRow, SongTableHeader } from "@/components/SongRow";
import { useMusic, type SortKey } from "@/lib/music-store";

export const Route = createFileRoute("/library")({
  head: () => ({ meta: [{ title: "Library — Sonata" }, { name: "description", content: "Every song in your library — sortable by name, artist, duration, rating or recency, filterable by genre/artist/duration/favorites." }] }),
  component: LibraryPage,
});

function LibraryPage() {
  const { state, sortSongs } = useMusic();
  const [sort, setSort] = useState<SortKey>("recent");
  const [genre, setGenre] = useState<string>("all");
  const [artist, setArtist] = useState<string>("all");
  const [durBucket, setDurBucket] = useState<"all" | "short" | "medium" | "long">("all");
  const [onlyFav, setOnlyFav] = useState(false);

  const genres = useMemo(() => Array.from(new Set(state.songs.map((s) => s.genre))).sort(), [state.songs]);
  const artists = useMemo(() => Array.from(new Set(state.songs.map((s) => s.artist))).sort(), [state.songs]);

  const filtered = useMemo(() => {
    let songs = state.songs;
    if (onlyFav) songs = songs.filter((s) => s.favorite);
    if (genre !== "all") songs = songs.filter((s) => s.genre === genre);
    if (artist !== "all") songs = songs.filter((s) => s.artist === artist);
    if (durBucket !== "all") {
      songs = songs.filter((s) =>
        durBucket === "short" ? s.duration < 210 :
        durBucket === "medium" ? s.duration >= 210 && s.duration < 270 :
        s.duration >= 270,
      );
    }
    return sortSongs(songs, sort);
  }, [state.songs, sort, genre, artist, durBucket, onlyFav, sortSongs]);

  return (
    <PageShell
      eyebrow="Library"
      title={`${state.songs.length} songs`}
      subtitle="Sorting is merge-sort by default (stable, O(n log n)); the rating sort uses quicksort. Filters compose over the array."
      hue={200}
    >
      <div className="glass flex flex-wrap items-center gap-2 rounded-2xl p-3 text-sm">
        <label className="text-xs text-muted-foreground">Sort</label>
        <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)} className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-sm">
          <option value="recent">Recently added</option>
          <option value="name">Name (A–Z)</option>
          <option value="artist">Artist</option>
          <option value="duration">Duration</option>
          <option value="rating">Rating</option>
        </select>
        <span className="mx-2 h-4 w-px bg-white/10" />
        <select value={genre} onChange={(e) => setGenre(e.target.value)} className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-sm">
          <option value="all">All genres</option>
          {genres.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <select value={artist} onChange={(e) => setArtist(e.target.value)} className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-sm">
          <option value="all">All artists</option>
          {artists.map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
        <select value={durBucket} onChange={(e) => setDurBucket(e.target.value as never)} className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-sm">
          <option value="all">Any duration</option>
          <option value="short">Short (&lt; 3:30)</option>
          <option value="medium">Medium (3:30–4:30)</option>
          <option value="long">Long (4:30+)</option>
        </select>
        <button
          onClick={() => setOnlyFav((v) => !v)}
          className={`rounded-full px-3 py-1 text-xs transition-colors ${onlyFav ? "bg-gradient-brand text-brand-foreground" : "bg-white/5 text-muted-foreground hover:text-foreground"}`}
        >
          ♥ Favorites
        </button>
        <span className="ml-auto text-xs text-muted-foreground">{filtered.length} shown</span>
      </div>

      <div className="glass rounded-2xl p-4 md:p-6">
        <SongTableHeader />
        <div className="space-y-1">
          {filtered.map((s, i) => (
            <SongRow key={s.id} index={i} song={s} contextIds={filtered.map((x) => x.id)} />
          ))}
        </div>
      </div>
    </PageShell>
  );
}