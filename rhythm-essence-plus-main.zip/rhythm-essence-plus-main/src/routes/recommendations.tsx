import { createFileRoute } from "@tanstack/react-router";
import { Sparkles } from "lucide-react";
import { useState } from "react";
import { PageShell } from "@/components/PageShell";
import { SongRow, SongTableHeader } from "@/components/SongRow";
import { AlbumCover } from "@/components/AlbumCover";
import { useMusic } from "@/lib/music-store";

export const Route = createFileRoute("/recommendations")({
  head: () => ({ meta: [{ title: "For You — Sonata" }, { name: "description", content: "Graph-based song recommendations from your favorites." }] }),
  component: RecPage,
});

function RecPage() {
  const { state, songById, recommendations } = useMusic();
  const [seed, setSeed] = useState<string | undefined>(state.favorites[0] ?? state.songs[0]?.id);
  const recs = recommendations(seed);
  const seedSong = seed ? songById(seed) : undefined;

  return (
    <PageShell
      eyebrow="For You"
      title="Smart recommendations"
      subtitle="Songs are nodes in an undirected weighted graph — edges connect tracks that share an artist, album, or genre. We BFS from your seed and rank by cumulative weight."
      hue={275}
      actions={<div className="glass rounded-full px-3 py-1.5 text-xs"><Sparkles className="mr-1 inline h-3 w-3 text-brand" /> Graph · BFS</div>}
    >
      <div className="glass rounded-2xl p-4 md:p-6">
        <div className="mb-3 text-xs uppercase tracking-wider text-muted-foreground">Seed song</div>
        <div className="flex flex-wrap gap-2">
          {state.songs.slice(0, 12).map((s) => (
            <button
              key={s.id}
              onClick={() => setSeed(s.id)}
              className={`flex items-center gap-2 rounded-full border px-2 py-1 pr-3 text-xs transition-all ${seed === s.id ? "border-brand bg-brand/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
            >
              <AlbumCover hue={s.coverHue} size={20} />
              <span className="truncate">{s.name}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="glass rounded-2xl p-4 md:p-6">
        <div className="mb-3 text-sm text-muted-foreground">
          {seedSong ? <>Because you like <b className="text-foreground">{seedSong.name}</b> by {seedSong.artist}:</> : "Pick a seed above."}
        </div>
        <SongTableHeader />
        <div className="space-y-1">
          {recs.map((s, i) => (
            <SongRow key={s.id} index={i} song={s} contextIds={recs.map((x) => x.id)} />
          ))}
        </div>
      </div>
    </PageShell>
  );
}