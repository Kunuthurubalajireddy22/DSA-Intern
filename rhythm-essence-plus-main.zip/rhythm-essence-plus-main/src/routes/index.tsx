import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, Flame, Music2, Sparkles, Star } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { PlaylistCard } from "@/components/PlaylistCard";
import { SongRow, SongTableHeader } from "@/components/SongRow";
import { StatCard } from "@/components/StatCard";
import { AlbumCover } from "@/components/AlbumCover";
import { fmtDuration, useMusic } from "@/lib/music-store";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const { state, sortSongs, topRated, mostPlayed, recommendations, songById, loadAndPlay } = useMusic();
  const recent = sortSongs(state.songs, "recent").slice(0, 6);
  const rated = topRated(6);
  const recs = recommendations();
  const played = mostPlayed();
  const totalDuration = state.songs.reduce((n, s) => n + s.duration, 0);
  const recentlyPlayed = state.recentPlays.map((id) => songById(id)).filter(Boolean).slice(0, 6);

  return (
    <PageShell
      eyebrow="Welcome back"
      title="Your library, structured beautifully."
      subtitle="Every playlist, search, and shuffle in Sonata is powered by a classic data structure or algorithm — visit the DSA Explorer to see how."
      hue={152}
      actions={
        <Link
          to="/dsa"
          className="glass-strong rounded-full px-4 py-2 text-sm font-medium transition-transform hover:scale-105"
        >
          Explore the DSA →
        </Link>
      }
    >
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Songs" value={state.songs.length} icon={<Music2 className="h-5 w-5" />} />
        <StatCard label="Playlists" value={state.playlists.length} icon={<Sparkles className="h-5 w-5" />} />
        <StatCard label="Favorites" value={state.favorites.length} icon={<Star className="h-5 w-5" />} />
        <StatCard label="Total time" value={fmtDuration(totalDuration)} icon={<Clock className="h-5 w-5" />} />
      </div>

      <section>
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-xl font-bold">Your playlists</h2>
          <span className="text-xs text-muted-foreground">Doubly linked list order</span>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {state.playlists.map((p) => <PlaylistCard key={p.id} playlist={p} />)}
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="glass rounded-2xl p-4 md:p-6">
          <div className="mb-3 flex items-center gap-2">
            <Flame className="h-4 w-4 text-brand" />
            <h3 className="text-lg font-bold">Top rated</h3>
            <span className="ml-auto text-xs text-muted-foreground">Max-Heap · top-K</span>
          </div>
          <div className="space-y-1">
            {rated.map((s, i) => (
              <SongRow key={s.id} index={i} song={s} contextIds={rated.map((x) => x.id)} />
            ))}
          </div>
        </div>

        <div className="glass rounded-2xl p-4 md:p-6">
          <div className="mb-3 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-accent" />
            <h3 className="text-lg font-bold">Recommended for you</h3>
            <span className="ml-auto text-xs text-muted-foreground">Graph · BFS</span>
          </div>
          {recs.length === 0 ? (
            <div className="text-sm text-muted-foreground">Favorite a song to unlock recommendations.</div>
          ) : (
            <div className="space-y-1">
              {recs.slice(0, 6).map((s, i) => (
                <SongRow key={s.id} index={i} song={s} contextIds={recs.map((x) => x.id)} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="glass rounded-2xl p-4 md:p-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-xl font-bold">Recently added</h2>
          <span className="text-xs text-muted-foreground">Merge sort · by addedAt</span>
        </div>
        <SongTableHeader />
        <div className="space-y-1">
          {recent.map((s, i) => (
            <SongRow key={s.id} index={i} song={s} contextIds={recent.map((x) => x.id)} />
          ))}
        </div>
      </section>

      {(played.length > 0 || recentlyPlayed.length > 0) && (
        <section className="grid gap-6 lg:grid-cols-2">
          {recentlyPlayed.length > 0 && (
            <div className="glass rounded-2xl p-4 md:p-6">
              <h3 className="mb-3 text-lg font-bold">Recently played</h3>
              <div className="flex gap-3 overflow-x-auto pb-2">
                {recentlyPlayed.map((s) => s && (
                  <button
                    key={s.id}
                    onClick={() => loadAndPlay(recentlyPlayed.filter(Boolean).map((x) => x!.id), s.id)}
                    className="group flex w-32 shrink-0 flex-col gap-2 text-left"
                  >
                    <AlbumCover hue={s.coverHue} size={128} className="w-full" />
                    <div className="truncate text-sm font-medium">{s.name}</div>
                    <div className="truncate text-xs text-muted-foreground">{s.artist}</div>
                  </button>
                ))}
              </div>
            </div>
          )}
          {played.length > 0 && (
            <div className="glass rounded-2xl p-4 md:p-6">
              <h3 className="mb-3 text-lg font-bold">Most played</h3>
              <div className="space-y-1">
                {played.map((s, i) => (
                  <SongRow key={s.id} index={i} song={s} contextIds={played.map((x) => x.id)} />
                ))}
              </div>
            </div>
          )}
        </section>
      )}
    </PageShell>
  );
}
